#ifndef _IMAGEDATA_H_
#define _IMAGEDATA_H_

extern const unsigned char zhihu[], yiyanp[], jitang[],toutiao[],baidu[],douban[],weizhi_[],guancha[],wendu[],shidu[],weibo[],qing[],duoyun[], yin[],zhenyu[],leizhenyu[],leizhenyubanyoubingbao[],xiaoyu[],zhongyu[],dayu[],mai[],baoyu[],dongyu[],yujiaxue[],zhenxue[],xiaoxue[],zhongxue[],daxue[],baoxue[],fuchen[],shachenbao[],dawu[],weizhi[],ling[],yi[],er[],san[],si[],wu[],liu[],qi[],ba[],jiu[];

#endif
